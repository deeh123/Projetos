use bdsunset;

INSERT INTO usuario VALUES(1,'Denise','admin','admin');



INSERT INTO evento VALUES(1,'6° FETEF','imagem/imagem1.jpg','O evento acontecerá no dia 18 de novembro, das 19h30 às 22h00, quando serão apresentados ao público projetos tecnológicos e inovadores desenvolvidos por alunos neste semestre, com a supervisão dos professores FAEX!','Apresentação pública de projetos tecnológicos e inovadores desenvolvidos por alunos FAEX, que visam contribuir com o mundo técnologico e social!','2016-11-18','18 Nov','http://www.faex.edu.br/agenda/82/fetef_3%C2%BA_dia_feira_tecnologica_da_faex',0);
INSERT INTO evento VALUES(2,'ROYAL WHITE 2016','imagem/imagem3.jpg','A Maior Festa eletronica do Sul de Minas, Royal white 2016.
						Dia 19 de Novembro toda a região reunida para celebrar esta nova fase da Royal. Faremos uma grande celebração open air com todo luxo e sofisticação que só a Royal sabe fazer. Lounges, bares, e um super palco.','A Maior Festa eletronica do Sul de Minas. Uma grande celebração open air com todo luxo e sofisticação que só a Royal sabe fazer.','2016-11-19','19 Nov','http://www.borasair.com.br/pouso-alegre/royal-white-2016-open-air/',0);
INSERT INTO evento VALUES(3,'MICHEL TELÓ','imagem/imagem4.jpg','Vista-se de Branco e Permita-se.
									Festa do Branco Sossega Madalena
                                    MICHEL TELÓ em Itatiba 26 de Novembro - Sábado.','Vista-se de Branco e Permita-se.
									Festa do Branco Sossega Madalena','2016-11-26','26 Nov','http://www.sossegamadalena.com.br/site/',60);
INSERT INTO evento VALUES(4,'WESLEY SAFADÃO','imagem/imagem5.jpg','O Fenômeno da música Brasileira agora na linda cidade de Extrema-MG. 17 de Dezembro de 2016, Sábado, às 22:00h. Vai perder Essa?','O Fenômeno da música Brasileira, agora na linda cidade de Extrema-MG.','2016-12-17','17 Dez','http://www.borasair.com.br/extrema/wesley-safad%C3%A3o-em-extrema-mg/',80);


