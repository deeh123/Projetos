SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `bdsunset` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `bdsunset` ;

-- -----------------------------------------------------
-- Table `bdsunset`.`usuario`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bdsunset`.`usuario` ;

CREATE TABLE IF NOT EXISTS `bdsunset`.`usuario` (
  `idusuario` INT NOT NULL,
  `nome` VARCHAR(80) NULL,
  `login` VARCHAR(80) NULL,
  `senha` VARCHAR(10) NULL,
  PRIMARY KEY (`idusuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bdsunset`.`evento`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bdsunset`.`evento` ;

CREATE TABLE IF NOT EXISTS `bdsunset`.`evento` (
  `idevento` INT NOT NULL,
  `nomeevento` VARCHAR(50) NULL,
  `imagemagenda` VARCHAR(80) NULL,
  `descricao` TEXT NULL,
  `brevedescricao` TEXT NULL,
  `data` DATE NULL,
  `descricaoData` TEXT NULL,
  `urlevento` VARCHAR(100) NULL,
  `valor` DECIMAL(10,2) NULL,
  PRIMARY KEY (`idevento`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `bdsunset`.`galeria`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `bdsunset`.`galeria` ;

CREATE TABLE IF NOT EXISTS `bdsunset`.`galeria` (
  `idevento` INT NOT NULL,
  `idfoto` INT NOT NULL AUTO_INCREMENT,
  `imagemgaleria` VARCHAR(80) NULL,
  `titulofoto` VARCHAR(45) NULL,
  PRIMARY KEY (`idfoto`, `idevento`),
  CONSTRAINT `fk1`
    FOREIGN KEY (`idevento`)
    REFERENCES `bdsunset`.`evento` (`idevento`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
