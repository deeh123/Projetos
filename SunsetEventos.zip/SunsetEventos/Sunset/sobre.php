<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();

?>

<!DOCTYPE html>
<html lang="ptr-br">

<head>
	<meta charset="utf-8">
	
		<title>
			Sobre
		</title>
		
		<link rel="stylesheet"  href="css/menu.css">
		<link rel="stylesheet"  href="css/sobre.css">
		
		<script src="audioplayerengine/jquery.js"></script>
        <script src="audioplayerengine/amazingaudioplayer.js"></script>
        <link rel="stylesheet" type="text/css" href="audioplayerengine/initaudioplayer-1.css">
        <script src="audioplayerengine/initaudioplayer-1.js"></script>
		
</head>
	
	<body>
		
		<header>
	
			<?php 
				include ("php/menu.php");
			?>
			
		</header>			
		
		<header>
			<br></br>	
			
				<div id="titulo">
					
						 <h1> <font>____</font> </h1>
						 <h2> <font >SUNSET</font> </h1>
						 <h3> <font >EVENTOS</font> </h1>
					
				</div>
				
			
				
		</header>
		
		<header>
		     <div id="historia">
		          <h1> <font >NOSSA</font> </h1>
				  <h2> <font >HISTÓRIA</font> </h1>
			 </div>
		</header>
		
		<div id="sobre">
                 <div id="coments">		
					 <i><font >	O site surgiu em meio a elaboração de um tema para o projeto da Faculdade, quando um integrante perguntou se havia algum evento para ser apreciado no final de semana com os amigos ou familiares, um simples momento de lazer e descontração.
					 Nesse momento chegamos a conclusão de que falta um espaço para divulgação e busca de informações sobre tais eventos, de uma maneira prática, entendível e agradável.<br> </br>
						Em meio a essa situação procuramos buscar uma solução para contribuir, em parte pelo menos, na resolução desse déficit. Sabemos que a cidade de Extrema-MG conta com uma grande quantidade de eventos, sendo culturais, musicais, barzinhos e pontos turísticos, que atendem a diversos públicos, mas não possuem uma divulgação efetiva.
					 Trabalhamos então no desenvolvimento deste site que possibilita desde pequenos a grandes eventos que possam ser divulgados de uma maneira mais ampla e efetiva em nossa cidade. <br> </br>
						O meio em que vivemos hoje é dominado pelas redes de internet, facilitando o fluxo de informação, que se tornou bem mais simples de ser repassado, mas por muitas vezes não contém conteúdos importantes e é apresentado de maneira errada e/ou equivocada. 
					 O interesse da equipe foca então, em trazer este site para facilitar a busca por tais informações sobre os eventos que procederão na cidade aos usuários da rede, que são maioria. <br> </br>
					 </font> </i>     
			     </div>
		</div>
		
		<div id="foto">
		     <div id="imagem">
               <figure><img src="imagem/adm/adriano.jpg" width="130px" height="130px"/></figure>
             </div>            
			
		     <div id="nome">
		     <font>Adriano Fernandes</font>
			 </div>
			 
			 <div id="a">
		     <a href="https://www.facebook.com/adriano.pereira.332" target="_blank"><img class="um" src="css/logos/facebook.png"/></a>
			 </div>
		</div>
		
		<div id="foto1">
		     <div id="imagem">
               <figure><img src="imagem/adm/denise.jpg" width="130px" height="130px"/></figure>
             </div> 
		
		     <div id="nome">
		     <font>Denise Ribeiro</font>
			 </div>
			 
			 <div id="a">
		     <a href="https://www.facebook.com/Denise.chs?fref=ts" target="_blank"><img class="um" src="css/logos/facebook.png"/></a>
			 </div>
		</div>
		
		<div id="foto2">
		     <div id="imagem">
               <figure><img src="imagem/adm/Marco.jpg" width="130px" height="130px"/></figure>
             </div> 
		   
		     <div id="nome">
		     <font>Marco Aurélio</font>
			 </div>
			 
			 <div id="a">
		     <a href="https://www.facebook.com/marcoaurelio.santossilva?fref=ts" target="_blank"><img class="um" src="css/logos/facebook.png"/></a>
			 </div>
		</div>
		
		<div id="foto3">
		     <div id="imagem">
               <figure><img src="imagem/adm/Raphael.jpg" width="130px" height="130px"/></figure>
             </div> 
		
		     <div id="nome">
		     <font>Raphael Gomes</font>
			 </div>
			 
			 <div id="a">
		     <a href="https://www.facebook.com/raphael.gomes.146?fref=ts" target="_blank"><img class="um" src="css/logos/facebook.png"/></a>
			 </div>
		</div>
		
		<div id="foto4">
		     <div id="imagem">
               <figure><img src="imagem/adm/tiago.jpg" width="130px" height="130px"/></figure>
             </div> 
			 
		     <div id="nome">
		     <font>Tiago Pereira</font>
			 </div>
			 
			 <div id="a">
		     <a href="https://www.facebook.com/tiagopereirasilvamelo?fref=ts" target="_blank"><img class="um" src="css/logos/facebook.png"/></a>
			 </div>
		</div>
		
		
	</body>
	
	<footer>
        <div id="rodape"></div>	
	</footer>

</html>