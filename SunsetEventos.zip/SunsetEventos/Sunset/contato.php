<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();


?>


<!DOCTYPE html>
<html lang="ptr-br">

<head>
	<meta http-equiv="content-Type" content="text/html; charset=iso-8859-1" />
	
		<title>
			Contato
		</title>
		
		<link rel="stylesheet"  href="css/menu.css">
		<link rel="stylesheet"  href="css/home.css">
		<link rel="stylesheet"  href="css/contato.css">
		
		<script src="audioplayerengine/jquery.js"></script>
        <script src="audioplayerengine/amazingaudioplayer.js"></script>
        <link rel="stylesheet" type="text/css" href="audioplayerengine/initaudioplayer-1.css">
        <script src="audioplayerengine/initaudioplayer-1.js"></script>
		
</head>
	
	<body>
		
		<header>
	
			<?php 
				include ("php/menu.php");
			?>
			
		</header>		
		
		<header>
			<br></br>	
			
				<div id="titulo">
					
						 <h1> <font>____</font> </h1>
						 <h2> <font >SUNSET</font> </h1>
						 <h3> <font >EVENTOS</font> </h1>
					
				</div>
				
				
	
		</header>
		
		
			<div id="contato">
				 <h1> <font>CONTATO</font> </h1>	
			</div>
					
 
    <form action="mail_send.php" method="POST">
      
		  <input type="hidden" name="_token" value="{{ csrf_token() }}">
	 
	 
		  <div id="nome" class="form-group">
			<input type="text" id="nome" name="nome" class="form-control" placeholder="Nome" required>
		  </div>
	 
	 
		  <div id="email" class="form-group">
			<input type="text" id="email" name="email" class="form-control" placeholder="E-Mail" required>
		  </div>
		  
		  
		  <div id="assunto" class="form-group">
			<input type="text" id="assunto" name="assunto" class="form-control" placeholder="Assunto" required>
		  </div>
	 
	 
		  <div id="mensagem" class="form-group">
			<textarea id="mensagem" name="mensagem" class="form-control" placeholder="Mensagem"required></textarea>
		  </div>
	 
	 
		  <button id="enviar" type="submit" class="btn btn-default">Enviar</button>
 
    </form>
	
	
		 <footer>
				<div id="rodape"></div>	
		</footer>
		
	</body>
	
	

</html>