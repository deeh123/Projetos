<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();

$mensagem = "";

if (isset($_GET["retorna"])){
	$mensagem = $_GET["retorna"];
}

?>

<!DOCTYPE html>
<html lang="ptr-br">

<head>
	<meta charset="utf-8">
	
		<title>
			Login
		</title>
	
        
		
		<link rel="stylesheet"  href="css/menu.css">
		<link rel="stylesheet"  href="css/home.css">
	    <link rel="stylesheet"  href="css/login.css">
		
		
</head>
	
	
	<body>
	
		
		<header>
		
			<?php 
				include ("php/menu.php");
			?>
			
		</header>		
     	
		<header>
			<br></br>		
			
				<div id="titulo">
					
						 <h1> <font>____</font> </h1>
						 <h2> <font >SUNSET</font> </h1>
						 <h3> <font >EVENTOS</font> </h1>
				</div>
				
				
		 <div id="login"> 
			<div id="login1">
			
			<form method="POST" action="validaUsuario.php" name="frmlogin">
			     
				 
				 <p>Login<br>
                 <span style='color: red; font-size: 12pt;'><?php echo $mensagem; ?></span></p>
				
				 <label id="email" for="email">Email: <br></br></label>
                 <input type="email"  name="login" placeholder="yourname@email.com" required>
				 <br></br>
				 
				 <label id="senha" for="senha">Senha: <br></br></label>
                 <input type="password" name="senha" placeholder="password" required>
				 <br></br>	
				 <br></br>
				 
				 <input id="buttonR" type="submit" value="OK" >

			 </form>
				 
			</div>	
		 </div>
		 
		</header>
		

	</body>
	
	

</html>