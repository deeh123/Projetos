<?php
session_start();
include("fileset.php");

$nomeevento = $_POST['txtevento'];
$descricao = $_POST['txtdescricao'];
$descricao = $_POST['txtdescricao'];
$valor = $_POST['txtvalor'];
$data = $_POST['txtdata'];
$datadescricao = $_POST["txtdatadescricao"];
$url = $_POST['txturl'];

include("php/conexao.php");

$SQL = '';
$SQL .= 'UPDATE evento SET ';
$SQL .= '                   nomeevento = '.chr(39).$nomeevento.chr(39).'';
$SQL .= '                  ,descricao = '.chr(39).$descricao.chr(39).'';
$SQL .= '                  ,data = '.$data.'';
$SQL .= '                  ,descricaoData ='.$datadescricao.'';
$SQL .= '                  ,urlevento = '.$hobby.'';
$SQL .= '                  ,valor = '.$valor.'';
$SQL .= '                  ,url = '.$url.'';
$SQL .= ' WHERE login = '.chr(39).$logindigitado.chr(39).'';
$SQL .= '';


$wresultado = mysqli_query($conexao, $SQL);
						
						
	if(!$wresultado)
	{
		$mensagem_erro = 'Erro de sintaxe na query:' . mysqli_error();
		$destino = 'http://localhost/Sunset//php/erro.php?msg='.$mensagem_erro;
		header("Location: $destino");
		exit;
		$destino = 'http://localhost/Sunset/php/erro.php?msg='.$SQL;
		header("Location: $destino");
		exit;
	}		
	else
	{
		mysqli_close($conexao);
		$destino = 'usuario-lista.php';
		header("Location: $destino");
		exit;
	}


?>