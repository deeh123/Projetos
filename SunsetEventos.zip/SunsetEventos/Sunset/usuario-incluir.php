<?php
session_start();
include("php/conexao.php");

$email = $_POST['txtemail'];
$senha = $_POST['txtsenha'];


include("php/conexao.php");

$SQL = 'INSERT INTO usuario VALUES('.chr(39).$email.chr(39).','.chr(39).$senha.chr(39).');';


$wresultado = mysqli_query($conexao, $SQL);
						
						
	if(!$wresultado)
	{
		$mensagem_erro = 'Erro de sintaxe na query:' . mysqli_error();
		$destino = 'http://localhost/Sunset/php/erro.php?msg='.$mensagem_erro;
		header("Location: $destino");
		exit;
		//$destino = 'http://localhost/Sunset/php/erro.php?msg='.$SQL;
		//header("Location: $destino");
		//exit;
	}		
	else
	{
		mysqli_close($conexao);
		$destino = 'agenda.php';
		header("Location: $destino");
		exit;
	}


?>