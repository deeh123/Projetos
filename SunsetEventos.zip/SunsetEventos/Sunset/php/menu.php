<div class="menu">
			  <ul>
				<li><a href="inicial.php">INICIO</a></li>
				<li><a href="agenda.php">AGENDA</a></li>
				<li><a href="fotos.php">FOTOS</a></li>
				<li><a href="sobre.php">SOBRE</a></li>
				<li><a href="contato.php">CONTATO</a></li>
				
				<?php if($_SESSION["login"] != ""){ 
						echo '<li><a href="admin.php">ADMIN</a></li>';
						echo '<li><a href="index.php">SAIR</a></li>';
					}else{
						echo '<li><a href="login.php">LOGIN</a></li>';
					}
				?>
					<a href="https://www.facebook.com/sunseteventosmg" target="_blank"><img class="um" src="css/logos/facebook.png"/></a>
					<a href="https://www.youtube.com/" target="_blank"><img class="dois" src="css/logos/youtube.png"/></a>
					<a href="https://www.instagram.com/sunset.eventosmg/?hl=pt-br" target="_blank"><img class="dois" src="css/logos/instagram.png"/></a>
					<a href="https://twitter.com/?lang=pt-br" target="_blank"><img class="dois" src="css/logos/twitter.png"/></a>
			  </ul>			  
</div>
