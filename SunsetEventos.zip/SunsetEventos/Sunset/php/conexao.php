<?php
	
$conexao = mysqli_connect('localhost', 'root', '', 'bdsunset');
if(!$conexao) {
	$mensagem_erro= 'Falha na conexão com o MySQL:' .mysqli_error();
	$destino = $_SESSION['raizurl'].'erro.php?msg='.$mensagem_erro;
	header("Location: $destino");
	}
	
	return($conexao);

?>