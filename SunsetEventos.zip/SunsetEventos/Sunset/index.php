<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();

$_SESSION["login"]="";
header("Location: inicial.php");

?>