<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();


include("php/conexao.php");
 
 
 $SQL ='SELECT data '.chr(10);
 $SQL .=' 	, imagemagenda '.chr(10);
 $SQL .=' 	, nomeevento'.chr(10);
 $SQL .=' 	, descricao'.chr(10);
 $SQL .=' 	, descricaoData'.chr(10);
 $SQL .=' 	, valor'.chr(10);
 $SQL .=' 	, urlevento'.chr(10);
 $SQL .=' FROM evento'.chr(10);
 $SQL .=' WHERE data <= curdate()'.chr(10);
 

 
 $resultado = mysqli_query($conexao, $SQL);


 if (!$resultado) {
      $mensagem_erro  = 'Erro de sintaxe na query: ' . mysqli_error() . "<br>";
      $mensagem_erro .= 'SQL executado: ' . $SQL;
      $destino = 'http://localhost/Sunset/php/erro.php?msg='.$mensagem_erro;
      header("Location: $destino");
      exit;
   }

    if (mysqli_num_rows($resultado) == 0) {
      $mensagem_erro .= 'Nenhum dado localizado';
      $destino = $_SESSION['raizurl'].'erro.php?msg='.$mensagem_erro;
      header("Location: $destino");
      exit;
   }
   
   header("Content-Type: text/html; charset=ISO-8859-1", true);
   
   $tabela = "";
   
   while ($linha = mysqli_fetch_assoc($resultado)) {
	$tabela .=   '<div id="evento_um"> '.chr(10);
	$tabela .=   '	<div id="conteudoUm">'.'.<img src='.$linha['imagemagenda'].'>'.'</div>.'.chr(10);
	$tabela .=   '	<div id="titulo_evento">'.chr(10);
	$tabela .=   '		'.$linha['nomeevento'].''.chr(10);
	$tabela .=   '	</div>'.chr(10);
	$tabela .=   '	<div id="descricao">'.chr(10);
	$tabela .=   '		<div id="font">'.$linha['descricao'].'</div>'.chr(10);
	$tabela .=   '	</div>'.chr(10);
	$tabela .=   '	<div id="ingresso">'.chr(10);
	$tabela .=   '		<div id="fontDois">'.'<p>R$</p>'.''.$linha['valor'].'</div>'.chr(10);
	$tabela .=   '	</div>'.chr(10);
	$tabela .=   '	<div id="saibaMais">'.chr(10);
	$tabela .=   '		<div id="fontTres">'.'<a target="_blank" href='.$linha['urlevento'].'>'.'SAIBA MAIS'.'</a>'.'</div>'.chr(10);
	$tabela .=   '	</div>'.chr(10);
	$tabela .=   '	<div id="data">'.chr(10);
	$tabela .=   '		'.$linha['descricaoData'].''.chr(10);
	$tabela .=   '	</div>'.chr(10);
	$tabela .=   '</div>'.chr(10);
  
  }
 
   
?>

<!DOCTYPE html>
<html lang="ptr-br">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
		<title>
			Agenda
		</title>
		
		<link rel="stylesheet"  href="css/menu.css">
		<link rel="stylesheet"  href="css/home.css">
		<link rel="stylesheet"  href="css/agenda.css">
		
		<script src="audioplayerengine/jquery.js"></script>
        <script src="audioplayerengine/amazingaudioplayer.js"></script>
        <link rel="stylesheet" type="text/css" href="audioplayerengine/initaudioplayer-1.css">
        <script src="audioplayerengine/initaudioplayer-1.js"></script>
		
</head>
	
	<body>
		
		<header>
	
			<?php 
				include ("php/menu.php");
			?>
			
		</header>		
		
		
		<header>
			<br></br>		
			<div id="titulo">
					
						 <h1> <font>____</font> </h1>
						 <h2> <font >SUNSET</font> </h1>
						 <h3> <font >EVENTOS</font> </h1>			
			</div>
    
				
		</header>
		
		<div id="agenda">
			<h1>AGENDA<h1>
		</div>
		
		
		
			<?php
				echo $tabela;
			?>
			
			
			
			
			<footer>
				<div id="rodape"></div>	
			</footer>
			
	</body>

</html>