<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();

$logindigitado = $_POST['login'];
$senhadigitada = $_POST['senha'];


include("php/conexao.php");
 
 $SQL='	select idusuario '; 
 $SQL.='from usuario ';
 $SQL.='where login='.chr(39).$logindigitado.chr(39) ;
 $SQL.=' and senha='.chr(39).$senhadigitada.chr(39).';';
 
 
 $resultado = mysqli_query($conexao, $SQL);

 if (!$resultado) {
      $mensagem_erro  = 'Erro de sintaxe na query: ' . mysqli_error() . "<br>";
      $mensagem_erro .= 'SQL executado: ' . $SQL;
      $destino = 'http://localhost/Sunset/php/erro.php?msg='.$mensagem_erro;
      header("Location: $destino");
      exit;
   }

   if (mysqli_num_rows($resultado) == 0) {
		header("Location: login.php?retorna=Login Inválido.");
   }
   else
	   {
		   $_SESSION["login"] = 'xxx';
		   header("Location: admin.php");
	   }
   
   
   
?>
