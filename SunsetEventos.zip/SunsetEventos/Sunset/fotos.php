<?php
session_cache_limiter("NO CACHE");
session_cache_expire(10);
session_start();
?>

<!DOCTYPE html>
<html lang="ptr-br">

<head>
	<meta charset="utf-8">
	
	<script language="javascript">
		function aumenta(obj){
			obj.height=obj.height*1.5;
			obj.width=obj.width*1.5;
			
		}
	 
			function diminui(obj){
			obj.height=obj.height/1.5;
			obj.width=obj.width/1.5;
			
		}
	</script>
	
		<title>
			Fotos
		</title>
		
	   <link rel="stylesheet"  href="css/foto.css">
	   <link rel="stylesheet"  href="css/menu.css">
	   
		
</head>
	
	<body>
		
		<header>
	
			<?php 
				include ("php/menu.php");
			?>
			
		</header>		
		
		
		<header>
		<br></br>
		
			<div id="titulo">
		
						<h1> <font>____</font> </h1>
						 <h2> <font >SUNSET</font> </h1>
						 <h3> <font >EVENTOS</font> </h1>
			</div>
			
			
			
		</header>
		
		<header>
		<br></br>
		<div id="titulo">
				
				<h4> <font> Extrema </font> </h4>
				<br> <br>
				 <div id="galery"> <center>
					
					<?php include ("funcaoFotos.php")?>					
					<?php  $_SESSION["nome"] = "festa fantasia porks";?>	
					<?php echo $galeria;?>
					
					
					
					
					<br><br><br>
					<ul>
							    <h5> <font><a href=""></a>5° FETEF - FAEX</font> </h5>
					 </ul>
					 
					</ul>			 
			
				</div>
					<br><br><br>
					
				
				<h4> <font> Bragança </font> </h4>
				<br> <br>
				<div id="galery"> <center>
					
					<?php include ("funcaoFotos.php")?> 
					<?php  $_SESSION["nome"] = "miss cambui";?>	
					<?php echo $galeria?> 
					
					
					
					<br><br><br>
					<ul>
							    <h5> <font><a href=""></a>Festa a Fantasia</font> </h5>
					 </ul>
					 
					</ul>			 
			
				</div>					
					
					<br> <br> <br>
					
					
					<h4> <font> Cambui </font> </h4>
					<br> <br>
				 <div id="galery"> <center>
						
						<?php include ("funcaoFotos.php")?> 
						<?php  $_SESSION["nome"] = "fetef";?>
						<?php echo $galeria?>
					
						
						
					<br> <br> <br>
					 <ul>
								<h5> <font> <a href=""></a> Miss Cambui 2017 </font> </h5>
						</ul>
			
				</div>
				</div>
		
		</header>
		
		<br><br><br><br><br><br><br><br><br><br><br>
	
	
		
	</body>
	
	<footer>
        <div id="rodape"></div>	
	</footer>

</html>