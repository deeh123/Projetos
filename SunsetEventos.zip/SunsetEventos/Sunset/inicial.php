<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();

include("php/conexao.php");

 $SQL ='SELECT data '.chr(10);
 $SQL .=' 	, descricaoData '.chr(10);
 $SQL .=' 	, nomeevento'.chr(10);
 $SQL .=' 	, brevedescricao'.chr(10);
 $SQL .=' FROM evento'.chr(10);
 $SQL .=' WHERE data <= curdate()'.chr(10);
 
 $resultado = mysqli_query($conexao, $SQL);
 

 if (!$resultado) {
      $mensagem_erro  = 'Erro de sintaxe na query: ' . mysqli_error() . "<br>";
      $mensagem_erro .= 'SQL executado: ' . $SQL;
      $destino = 'http://localhost/Sunset/php/erro.php?msg='.$mensagem_erro;
      header("Location: $destino");
      exit;
   }

    if (mysqli_num_rows($resultado) == 0) {
      $mensagem_erro .= 'Nenhum dado localizado';
      $destino = $_SESSION['raizurl'].'erro.php?msg='.$mensagem_erro;
      header("Location: $destino");
      exit;
   }
   
   header("Content-Type: text/html; charset=ISO-8859-1", true);
   
   
   $tag = "";
   while ($linha = mysqli_fetch_assoc($resultado)) {
	   
			$tag .=   '<div id="conteudo">'.chr(10);
			$tag .=   '	<div id="evento">'.chr(10);
			$tag .=   ' 		'.$linha['descricaoData'].''.chr(10);
			$tag .=   '	</div>'.chr(10);
			$tag .=   '	<div id="titulo_evento">'.chr(10);
			$tag .=   '		<a href="agenda.php">'.$linha['nomeevento'].''.chr(10);
			$tag .=   '	</div>'.chr(10);
			$tag .=   '	<div id="descricao">'.chr(10);
			$tag .=   '		'.$linha['brevedescricao'].''.chr(10);
			$tag .=   '	</div>'.chr(10);	
			$tag .=   '	</div>'.chr(10);
	
  }
	 

?>


<!DOCTYPE html>
<html lang="ptr-br">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
		<title>
			Sunset Eventos
		</title>
		
		<link rel="stylesheet"  href="css/menu.css">
		<link rel="stylesheet"  href="css/home.css">
		
		
		
</head>
	
	
	<body>
	
		
		<header>
	
			<?php 
				include ("php/menu.php");
			?>
			
		</header>		
     	
		<header>
			<br></br>	
			
				<div id="titulo">
					
						 <h1> <font>____</font> </h1>
						 <h2> <font >SUNSET</font> </h1>
						 <h3> <font >EVENTOS</font> </h1>					
				</div>
				
				
		</header>
		
				<?php echo $tag ?>
				 
		
		<footer>
			<div id="rodape"></div>	
		</footer>
		

	</body>
	
	
	

</html>