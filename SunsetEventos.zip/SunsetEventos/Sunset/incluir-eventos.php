<?php
session_start();
include("php/conexao.php");

$nomeevento = $_POST['txtevento'];
$descricao = $_POST['txtdescricao'];
$valor = $_POST['txtvalor'];
$data = $_POST['txtdata'];
$datadescricao = $_POST["txtdatadescricao"];
$url = $_POST['txturl'];


include("php/conexao.php");

$SQL = 'INSERT INTO evento VALUES('.chr(39).$nomeevento.chr(39).','.chr(39).$descricao.chr(39).','.chr(39).$valor.chr(39).','.$data.','.$datadescricao.','.$url.');';


$wresultado = mysqli_query($conexao, $SQL);
						
						
	if(!$wresultado)
	{
		$mensagem_erro = 'Erro de sintaxe na query:' . mysqli_error();
		$destino = 'http://localhost/Sunset/php/erro.php?msg='.$mensagem_erro;
		header("Location: $destino");
		exit;
		//$destino = 'http://localhost/Sunset/php/erro.php?msg='.$SQL;
		//header("Location: $destino");
		//exit;
	}		
	else
	{
		mysqli_close($conexao);
		$destino = 'agenda.php';
		header("Location: $destino");
		exit;
	}


?>