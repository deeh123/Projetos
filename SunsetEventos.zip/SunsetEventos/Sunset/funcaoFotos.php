<?php

$conexao = mysqli_connect("localhost","root","","bdsunset");

if (!$conexao) {
   $mensagem_erro= 'Falha na conexão com o MySQL: ' . mysqli_error();
   $destino = 'php/erro.php?msg='.$mensagem_erro;
	header("Location: $destino");
   exit;
}

$n = 1; $s = 2; $r = 3; $p = 4;



	
	//$galeria = ' <div id="gallery"> <center> '.chr(10);
	$galeria ='				<ul>'.chr(10);
	$galeria .='					<li> '.chr(10);
	$galeria .='					<marquee  behavior="alternate" scrolldelay="1">'.chr(10);
	$galeria .='							<a href=""imagem/imagem1.jpg""  title="Imagem 1"><img src="imagem/'.$_SESSION["nome"].'/'.$_SESSION["nome"].''.$n.'.jpg" width="160" height="160" alt="" title="Img#1" onMouseOver="aumenta(this)" onMouseOut="diminui(this)" /></a> '.chr(10);
	$galeria .='							<a href=""imagem/imagem2.jpg""  title="Imagem 2"><img src="imagem/'.$_SESSION["nome"].'/'.$_SESSION["nome"].''.$s.'.jpg" width="160" height="160" alt="" title="Img#2" onMouseOver="aumenta(this)" onMouseOut="diminui(this)"/></a> '.chr(10);
	$galeria .='							<a href=""imagem/imagem3.jpg""  title="Imagem 3"><img src="imagem/'.$_SESSION["nome"].'/'.$_SESSION["nome"].''.$r .'.jpg" width="160" height="160" alt="" title="Img#3" onMouseOver="aumenta(this)" onMouseOut="diminui(this)"/></a> '.chr(10);
	$galeria .='							<a href=""imagem/imagem4.jpg""  title="imagem 4"><img src="imagem/'.$_SESSION["nome"].'/'.$_SESSION["nome"].''.$p .'.jpg" width="160" height="160" alt="" title="Img#4" onMouseOver="aumenta(this)" onMouseOut="diminui(this)"/></a> '.chr(10);
	
	$galeria .='						</marquee> '.chr(10);
						
	$galeria .='					</li> '.chr(10);
	
					 
	//$galeria .='				</ul> '.		chr(10);	 
			
	//$galeria .='				</div> '.chr(10);


?>
