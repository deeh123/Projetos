<?php
session_cache_limiter('nocache');
session_cache_expire(10);
session_start();

?>

<!DOCTYPE html>
<html lang="ptr-br">

<head>
	<meta charset="utf-8">
	
		<title>
			Adiministrativo
		</title>
		
		<link rel="stylesheet"  href="css/menu.css">
		<link rel="stylesheet"  href="css/home.css">
		<link rel="stylesheet"  href="css/admin.css">
		
</head>
	
	<body>
		
		<header>
		
			<?php 
				include ("php/menu.php");
			?>
			
		</header>		
		
		
		<header>
			<br></br>		
			<div id="titulo">
					
						 <h1> <font>____</font> </h1>
						 <h2> <font >SUNSET</font> </h1>
						 <h3> <font >EVENTOS</font> </h1>
					
				</div>
		</header>
		
		
			<div id="contato">
				 <h1> <font>Cadastro do Evento</font> </h1>	
			</div>
					
 
		<form action="incluir-eventos.php" method="POST">
			  
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
		 
		 
			<div id="titulo" class="form-group">
				<input type="text" id="titulo" name="txtevento" class="form-control" placeholder="Titulo do evento" required>
			</div>
		 
			<div id="descricao" class="form-group">
				<input type="text" id="descricao" name="txtdescricao" class="form-control" placeholder="Descricao do evento" required>
			</div>
				
			<div id="valor" class="form-group">
				<input type="text" id="valor" name="txtvalor" class="form-control" placeholder="Valor do ingresso" required>
			</div>
		
			<div id="data" class="form-group">
				<input id="data" name="txtdata" class="form-control" placeholder="Data" required></textarea>
			</div>
			
			<div id="data" class="form-group">
				<input id="data" name="txtdatadescricao" class="form-control" placeholder="Data descricao"></textarea>
			</div>
			
			<div id="url" class="form-group">
				<input id="url" name="txturl" class="form-control" placeholder="Url do site do cliente" required></textarea>
			</div>
			
			<div id="foto" class="form-group">
				<input id="foto" name="foto" class="form-control" placeholder="Foto" required></textarea>
				<button id="inserirFoto" type="submit" class="btn btn-default">Inserir Foto</button>
			</div>
		 
			<div>
				<button id="enviar" type="submit" class="btn btn-default">Enviar</button>
			</div>
		</form>
			
			<div>
			
				<div> <h1> <hr width=48% color=white size=4 align=center> </h1> </div> 
			
			</div>
		
		  <div id="contato">
			<h1> <font>Alterar Evento</font> </h1>	
		  </div>
		  
		<form action="" method="POST">
		  
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
		 
		 
			<div id="id" class="form-group">
			<input type="text" id="id" name="id" class="form-control" placeholder="ID">
			</div>
		 
		 
			<div>
				<button id="consulta" type="submit" class="btn btn-default">Consulta</button>
			</div>
			
		</form>

		<br></br>
		
		<form action="evento-altera.php" method="POST">
		  
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
		 
			  
			<div id="titulo" class="form-group">
				<input type="text" id="titulo" name="titulo" class="form-control" placeholder="Titulo do evento">
			</div>
		 
			<div id="descricao" class="form-group">
				<input type="text" id="descricao" name="descricao" class="form-control" placeholder="Descricao do evento">
			</div>
				
			<div id="valor" class="form-group">
				<input type="text" id="valor" name="valor" class="form-control" placeholder="Valor do ingresso">
			</div>
		 
			<div id="data" class="form-group">
				<input id="data" name="data" class="form-control" placeholder="Data"></textarea>
			</div>
			
			<div id="data" class="form-group">
				<input id="data" name="datadescricao" class="form-control" placeholder="Data descricao"></textarea>
			</div>
			
			<div id="url" class="form-group">
				<input id="url" name="url" class="form-control" placeholder="Url do site do cliente" required></textarea>
			</div>
		 
			<div id="foto" class="form-group">
				<input id="foto" name="foto" class="form-control" placeholder="Foto" required></textarea>
				<button id="inserirFoto" type="submit" class="btn btn-default">Alterar Foto</button>
			</div>
		 
			<div>
				<button id="alterarCadastro" type="submit" class="btn btn-default">Alterar Cadastro</button>	
				<button id="excluir" type="submit" class="btn btn-default">Excluir</button>
			</div>
		
		</form>
		
		<br></br>
		
		<div>
			
			<div> <h1> <hr width=48% color=white size=4 align=center> </h1> </div> 
			
		</div>
	 
					<div id="contato">
					 <h1> <font>Incluir Usuario</font> </h1>	
				</div>
						
	 
		<form action="incluir-usuario.php" method="POST">
		  
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
		 
			<div id="email" class="form-group">
				<input type="password" id="email" name="txtemail" class="form-control" placeholder="Email" required>
			</div>
		 
			<div id="senha" class="form-group">
				<input type="password" id="valor" name="txtsenha" class="form-control" placeholder="Senha" required>
			</div>
				
			<div id="senha" class="form-group">
				<input type="password" id="valor" name="txtsenha" class="form-control" placeholder="Digite sua senha novamente" required>
			</div>
	 
			<div>
				<button id="registrar" type="submit" class="btn btn-default">Registrar</button>
			</div>
			
		</form>
		
	
	</body>
	
	

</html>