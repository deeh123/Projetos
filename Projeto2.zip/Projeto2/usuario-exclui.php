<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<?php
session_start();
include("fileset.php");

$login = $_GET["login"];
$ArrayUsuario = ObtemDadoUsuario($login);
?>

<html>

	<head>

	<meta http-equiv="Content-type" content="text/html; charset=UTF-8"> 
		<link rel="stylesheet" href="http://localhost/Projeto2/css/menu.css" type="text/css" />
		<link rel="stylesheet" href="http://localhost/Projeto2/css/estilo.css" type="text/css" />
		<script type="text/javascript" src="http://localhost/Projeto2/script/ValidaAltUsuario.js" charset="utf-8"> </script>
		
		<title>
		  Incluir Usuário
		</title>
	
	</head>

<body>
<form name="frmusuario" method="post">

<table style="width:100%; border-collapse: collapse; border-spacing: 0;">

	<?php include("php/cabecalho.php");?>
	

	<tr height="5px">
		<td colspan="4"> <hr noshaded size="1" color="lightblue"> </td>
	</tr>
	
	<tr>
		<td colspan="3"> 
		
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
			<tr width="12%" valign="top">
				<script src="http://localhost/projeto2/script/menu.js"> </script>
			</tr>
				
				<tr height="5px">
					<td colspan="4">&nbsp; </td>
				</tr>
					
					<tr> 
						<td colspan="4" font-family = Arial font-size = 9pt>&nbsp; <b>
						Permite a Exclusao de Usuarios no Sistema.</b>
						</td>
					</tr>
						
						<tr height="20px">
							<td colspan="4">&nbsp; </td>
						</tr>
		</td>
	</tr>
	</table>
	<table class= "usuario">
				<tr> 
					<td>&nbsp; </td>
					<td width="10px"> Nome: </td>
					<td><input type="text" name="txtnome" size="50" maxlength="50" value="<?php echo $ArrayUsuario[2] ?>" readonly /></td>
					<td> &nbsp; </td>
				</tr>
								
				<tr>
					<td>&nbsp;</td>
					<td> Usuario: </td>
					<td><input type="text" name="txtusuario" size="8" maxlength="8" value="<?php echo $ArrayUsuario[0] ?>" readonly /> </td>
					<td> &nbsp; </td>
											
				</tr>
										
				<tr> 
					<td>&nbsp;</td>
					<td> Senha: </td>
					<td><input type="password" name="txtsenha" size="8" maxlength="8" value="<?php echo $ArrayUsuario[1] ?>" readonly /> </td>
					<td> &nbsp; </td>
				</tr>
			
			<tr>
				<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
			
			
		<tr>		
			<td>&nbsp;</td>
			<td  colspan=2> Perfil Usuario: </td>
		</tr>
				
			<tr>
				<td colspan=2> </td>
				<td> <input type="radio" name="txtperfil" value="1"<?php if($ArrayUsuario[3]==1) echo'checked="checked"'; ?> disabled='disabled' > Administrador </td>
			</tr>
		
			<tr>
				<td colspan=2> </td>
				<td> <input type="radio" name="txtperfil" value="2"<?php if($ArrayUsuario[3]==2) echo'checked="checked"'; ?> disabled='disabled' > Controle Estoque</td>
			</tr>
			
			<tr>
					<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
		
		
		<tr>
				<td>&nbsp </td>
				<td> Departamento: </td>
				<td>
					<?php echo ComboDeptoCons($login); ?>
				</td>
		</tr>
		
			<tr>
					<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
		
		<tr>		
			<td>&nbsp;</td>
			<td> Cursos de Lingua:  </td>		
			<td>
					<select name="nome" size=4>
						<option value='1'<?php if($ArrayUsuario[5]==1) echo'selected="selected"'; ?> disabled='disabled'> Inglês</option> 
						<option value='2'<?php if($ArrayUsuario[5]==2) echo'selected="selected"'; ?> disabled='disabled'> Espanhol</option>
						<option value='3'<?php if($ArrayUsuario[5]==3) echo'selected="selected"'; ?> disabled='disabled'> Francês</option>
						<option value='4'<?php if($ArrayUsuario[5]==4) echo'selected="selected"'; ?> disabled='disabled'> Outros</option>
					</select>
			</td>
		</tr>
		
		<tr>
					<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
		
		
		<tr>		
			<td>&nbsp;</td>
			<td  colspan=4> Hobbys que o funcionario prática: </td>
		</tr>
		
		<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="caminhada" value="1" <?php if($ArrayUsuario[6]==1) echo'checked="checked"'; ?> disabled='disabled'>Caminhada </td>
			</tr>
			
			<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="corrida" value="2" <?php if($ArrayUsuario[6]==2) echo'checked="checked"'; ?> disabled='disabled'> Corrida</td>
			</tr>
			
			<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="Dança" value="3" <?php if($ArrayUsuario[6]==3) echo'checked="checked"'; ?> disabled='disabled'>Dança </td>
			</tr>
			
			<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="futebol" value="4" <?php if($ArrayUsuario[6]==4) echo'checked="checked"'; ?> disabled='disabled'>Futebol </td>
			</tr>
			
			<tr>
					<td colspan="2"> &nbsp; </td>
					<td align="left"> <input type="button" name="botaoExcluir" value="Excluir" onclick="JavaScript:ExcluirUsuario();"> </td>
					<td> &nbsp; </td>
		</tr>
	</table>
</table>
	
</form>
</body>

</html>