<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<?php
	session_start();
	include ("fileset.php");
	
	$logindigitado = $_POST['txtusuario'];
	$senhadigitada = $_POST['txtsenha'];
	$_SESSION["datacorrente"] = exibedatacorrente();
	$_SESSION["nomeusuario"] = validaUsuario($logindigitado, $senhadigitada);
?>	
	

<html>

<head>
<!-- utilizado para html 4-->
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8"> 
	<link rel="stylesheet" href="css/menu.css" type="text/css" />

</head>
<body>
<form name="frmpaginainicial" method="post">
<table style="width:100%;
	border-collapse: collapse;
	border-spacing: 0;">
	
	<?php include("php/cabecalho.php");?>
	
	<tr height="5px">
		<td colspan="4"> <hr noshaded size="1" color="lightblue"> </td>
	</tr>
	
	<tr>
		<td colspan="3"> 
			<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tr width="12%" valign="top">
					<script src="script/menu.js"> </script>
					
					<tr width="88%" valign="top">
						<td align="middle"> <img src="imagem/ControleDeEstoque.jpg"> </td>
					</tr>
				</tr>
				
			</table>
		</td>
	</tr>
	
</table>

</body>
</html>