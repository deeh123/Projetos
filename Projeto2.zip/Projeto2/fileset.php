<?php

include("php/funcoes_genericas.php");
include("php/funcoes_usuario.php");

?>
