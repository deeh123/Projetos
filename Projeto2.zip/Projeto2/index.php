<?php
	session_start();
	include("fileset.php");
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
<!-- utilizado para html 4-->
<meta http-equiv="Content-type" content="text/html; charset=UTF-8"> 
<script type="text/javascript" src="http://localhost/Projeto2/script/ValidaLogin.js" charset="utf-8"> </script>
<link rel="stylesheet" href="http://localhost/Projeto2/css/estilo.css" type="text/css" />

	<title>
	  Login
	</title>
</head>

<body>
 
	<form name="frmlogin" method="post">
	<table class="pagina">
	
		<tr class="cabecalho">
			<td width="34%" colspan="2"> </td>
			<td width="49%"> 
				<font size="6" align="center" color="black">
					Controle de Estoque
				</font>
				</td>
			<td width="17%" align="right"> <img src="http://localhost/Projeto2/imagem/faex.jpg"> </td>
		</tr>
		
		<tr height="5px">
			<td colspan="4">&nbsp; </td>
		</tr>
		
		<tr height="5px">
			<td colspan="4"> <hr noshaded size="1" color="#4682B4"></td>
		</tr>
		
		<tr>
		</tr>
		
		<tr>
			<td colspan="4" align = "center"> 
				<table class="login">
					<tr>
						<td colspan="4">&nbsp; </td>
					</tr>
					
					<tr>
						<td>&nbsp;<td>
						<td width="10px">Usu&aacute;rio</td>
						<td> <input type="text" name="txtusuario" size="8" maxlength="8" value=""> </td>
						<td>&nbsp; </td>
					</tr>
					
					<tr>
						<td>&nbsp;<td>
						<td> Senha:</td>
						<td> <input type="password" name="txtsenha" size="8" maxlength="8" value=""> </td>
						<td>&nbsp;<td>	
					</tr>
					
					<tr>
						<td colspan="2">&nbsp;</td>
						<td align="left"> <input type="button" name="botaologin" value="Entrar" onclick="JavaScript:ValidaLogin();"></td>
						<td>&nbsp; </td>
					</tr>
					
					<tr>
						<td colspan="4"> &nbsp;</td>
					</tr>
				</table>
			</td>
				
		</tr>
	</table>
	
	
	
</form>
</body>

</html>