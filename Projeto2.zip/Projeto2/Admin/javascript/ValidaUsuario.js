function ValidaUsuario()
{
	
	if(document.frmincluir.txtnome.value=="")
	{
		document.frmincluir.txtnome.style.background = 'Yellow';
		alert("Favor preencher o Nome");
		document.frmincluir.txtnome.focus();
		return false;
		
	}
	else
		document.frmincluir.txtNome.style.background = 'White';
	
	if(document.frmincluir.txtusuario.value=="")
	{
		document.frmincluir.txtusuario.style.background = 'Yellow';
		alert("Favor preencher o Nome");
		document.frmincluir.txtusuario.focus();
		return false;
		
	}
	else
		document.frmPaginaUm.txtusuario.style.background = 'White';
	
	
	
	
	
	    document.forms[0].action = "http://localhost/Projeto2/usuario-incluir-bd.php";
		document.forms[0].submit();
}
	
		
	