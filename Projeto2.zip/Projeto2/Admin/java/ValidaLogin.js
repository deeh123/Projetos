function ValidaLogin()
{
	
	if(document.frmPaginaUm.txtnome.value=="")
	{
		document.frmPaginaUm.txtnome.style.background = 'Yellow';
		alert("Favor preencher o seu NOME.");
		document.frmPaginaUm.txtnome.focus();
		return false;
	}
	else
		document.frmPaginaUm.txtnome.style.background = 'White';
	
			if(document.frmPaginaUm.txtUsuario.value=="")
			{
				document.frmPaginaUm.txtUsuario.style.background = 'Yellow';
				alert("Favor preencher o seu Usuario de login.");
				document.frmPaginaUm.txtUsuario.focus();
				return false;
			}
			else
				document.frmPaginaUm.txtUsuario.style.background = 'White';
					
					
						if(document.frmPaginaUm.txtSenha.value=="")
				{
					document.frmPaginaUm.txtSenha.style.background = 'Yellow';
					alert("Favor preencher a sua Senha.");
					document.frmPaginaUm.txtSenha.focus();
					return false;
				}
				else
					document.frmPaginaUm.txtSenha.style.background = 'White';
				
						if (document.frmPaginaUm.txtperfil.checked==false
							&& document.frmPaginaUm.txtperfil.checked==false)
									
							{
								alert('Por favor,selione o Perfil do Usuário');
								return false;
							}
							
							
							var tamanhoDepartamentos = document.frmPaginaUm.departamentos.length;
							var selecionado = 0
						
							for (var i=0;i< tamanhoDepartamentos;i++)
							{
								if(document.frmPaginaUm.departamentos[i].selected)
								{
									selecionado++
								}
							}
							
							if(selecionado==0)
							{
								alert("Slecione pelo menos um tipo de Departamento")
								return false
							}
							else

						if(document.frmPaginaUm.caminhada.checked==false
						&& document.frmPaginaUm.corrida.checked==false
						&& document.frmPaginaUm.futebol.checked==false)
						{
							alert('Por favor,selione pelo menos uma opção de Hobbys quepratica.');
							return false;
						}					

	document.forms[0].action="http://localhost/exercicio2/pagina_inicial.php";
	document.forms[0].submit();	
	
	
}