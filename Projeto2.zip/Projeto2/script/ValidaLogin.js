function ValidaLogin()
{
	if(document.frmlogin.txtusuario.value=="")
	{
		document.frmlogin.txtusuario.style.background='yellow';
		alert("Favor preencher o campo Usuário" );
		document.frmlogin.txtusuario.focus();
		return false;
	}
	else
		document.frmlogin.txtusuario.style.background='white';
	if (document.frmlogin.txtsenha.value=="")
	{
		document.frmlogin.txtsenha.style.background='yellow';
		alert("Favor preencher o campo Senha" );
		document.frmlogin.txtsenha.focus();
		return false;
	}
	else if (document.frmlogin.txtsenha.value.length<4)
	{
		document.frmlogin.txtsenha.style.background = 'yellow';
		alert("Favor verificar, campo senha deve ser preenchido co pelo menos 4 caracteres.");
		document.frmlogin.txtsenha.focus();
		return false;
	}
	if 
		 (document.frmlogin.txtsenha.value.search(/[0-9]+/)==-1)
		 {
			document.frmlogin.txtsenha.style.background='yellow';
			alert("Favor verificar, campo senha deve ser preenchido co pelo menos uma letra e um numero.");
			document.frmlogin.txtsenha.focus();
			return false;
		 }
		 
	document.forms[0].action="http://localhost/Projeto2/pagina_inicial.php";
	document.forms[0].submit();
}	
