function ValidaAltUsuario()
{ 

	
	if(document.frmusuario.txtnome.value=="")
	{
	document.frmusuario.txtnome.style.background= 'Yellow';
	alert("Favor preencher o campo Nome");
	document.frmusuario.txtnome.focus();
	return false;
	}
	else
		document.frmusuario.txtnome.style.background= 'white';
	
	
	
	if(document.frmusuario.txtusuario.value=="")
	{
	document.frmusuario.txtusuario.style.background= 'Yellow';
	alert("Favor preencher o campo Usuario");
	document.frmusuario.txtusuario.focus();
	return false;
	}
	else
		document.frmusuario.txtusuario.style.background= 'white';
	
	
	
	if(document.frmusuario.txtsenha.value=="")
	{
	document.frmusuario.txtsenha.style.background= 'Yellow';
	alert("Favor preencher o campo Senha");
	document.frmusuario.txtsenha.focus();
	return false;
	}
	else
		document.frmusuario.txtsenha.style.background= 'white';
	
	
	
	if(document.frmusuario.txtsenha.value.length<4)
	{
	document.frmusuario.txtsenha.style.background= 'Yellow';
	alert("Favor preencher o campo senha com 4 digitos");
	document.frmusuario.txtsenha.focus();
	return false;
	}
	else
		document.frmusuario.txtsenha.style.background= 'white';
	
	if (document.frmusuario.txtperfil[0].checked == false
	&& document.frmusuario.txtperfil[1].checked == false)
	{
		alert('Selecione um dos perfis para continuar');
	return false;
	}
	else

	
	
	document.forms[0].action = "http://localhost/Projeto2/usuario-alterar-bd.php";
    document.forms[0].submit();
}