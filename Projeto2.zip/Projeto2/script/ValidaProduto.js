function ValidaProduto()
{
	
	if(document.frmprodincluir.codproduto.value.search(/[0-9]+/)==-1)
	{
		document.frmprodincluir.codproduto.style.background='red';
		alert("Favor preencher o campo Código" );
		document.frmprodincluir.codproduto.focus();
		return false;
	}
	else
		document.frmprodincluir.codproduto.style.background='white';
	if (document.frmprodincluir.txtnome.value=="")
	{
		document.frmprodincluir.txtnome.style.background='red';
		alert("Favor preencher o campo Nome" );
		document.frmprodincluir.txtnome.focus();
		return false;
	}
	else
		document.frmprodincluir.txtnome.style.background='white';
	if (document.frmprodincluir.codquantidade.value=="")
	{
		document.frmprodincluir.codquantidade.style.background='red';
		alert("Favor preencher o campo Quantidade" );
		document.frmprodincluir.codquantidade.focus();
		return false;
	}
	else
		document.frmprodincluir.codquantidade.style.background='white';
	
	if (document.frmprodincluir.txtdescricao.value=="")
	{
		document.frmprodincluir.txtdescricao.style.background='red';
		alert("Favor preencher o campo Descrição" );
		document.frmprodincluir.txtdescricao.focus();
		return false;
	}
	else
		document.frmprodincluir.txtdescricao.style.background='white';
		
	document.forms[0].action="pagina_inicial.html";
	document.forms[0].submit();
}	
