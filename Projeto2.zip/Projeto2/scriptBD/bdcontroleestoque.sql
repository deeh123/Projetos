drop database controleestoque;
create database controleestoque;

CREATE TABLE controleestoque.usuario
( login varchar(8) NOT NULL ,
senha int (8) NOT NULL,
nome varchar(50) NOT NULL,
perfil int NOT NULL,
departamento int NOT NULL,
curso_lingua int NOT NULL,
hobby int NOT NULL,
PRIMARY KEY (login))
ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO controleestoque.usuario VALUES('Rapha',12345,'Raphael Gomes',1,1,1,1);
INSERT INTO controleestoque.usuario VALUES('gomes',1234,'Raphags',1,1,1,1);


