<?php
session_start();
include("fileset.php");

$nomeusu = $_POST['txtnome'];
$loginusu = $_POST['txtusuario'];
$senhausu = $_POST['txtsenha'];

$perfil = $_POST['txtperfil'];
$deptoselecionado = $_POST["combodepto"];
$cursos = $_POST['nome'];

if(isset($_POST['caminhada'])) {$hobby = 1;}
if(isset($_POST['corrida'])) {$hobby = 2;}
if(isset($_POST['danca'])) {$hobby = 3;}
if(isset($_POST['futebol'])) {$hobby = 4;}

include("php/conexao.php");

$SQL = 'INSERT INTO usuario VALUES
('.chr(39).$loginusu.chr(39).','.chr(39).$senhausu.chr(39).','.chr(39).$nomeusu.chr(39).','.$perfil.','.$deptoselecionado.','.$cursos.','.$hobby.');';



$wresultado = mysqli_query($conexao, $SQL);
						
						
	if(!$wresultado)
	{
		$mensagem_erro = 'Erro de sintaxe na query:' . mysqli_error();	
		$destino = 'http://localhost/Projeto2/php/erro.php?msg='.$mensagem_erro;
		header("Location: $destino");
		exit;
	}		
	else
	{
		mysqli_close($conexao);
		$destino = 'usuario-lista.php';
		header("Location: $destino");
		exit;
	}


?>