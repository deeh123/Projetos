<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<?php
session_start();
include("fileset.php");
?>

<html>

	<head>

	<meta http-equiv="Content-type" content="text/html; charset=UTF-8"> 
		<link rel="stylesheet" href="http://localhost/Projeto2/css/menu.css" type="text/css" />
		<link rel="stylesheet" href="http://localhost/Projeto2/css/estilo.css" type="text/css" />
		<script type="text/javascript" src="http://localhost/Projeto2/script/ValidaUsuario.js" charset="utf-8"> </script>
		
		<title>
		  Incluir Usuário
		</title>
	
	</head>

<body>
<form name="frmusuario" method="post">

<table style="width:100%; border-collapse: collapse; border-spacing: 0;">

	<?php include("php/cabecalho.php");?>
	

	<tr height="5px">
		<td colspan="4"> <hr noshaded size="1" color="lightblue"> </td>
	</tr>
	
	<tr>
		<td colspan="3"> 
		
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
			<tr width="12%" valign="top">
				<script src="http://localhost/projeto2/script/menu.js"> </script>
			</tr>
				
				<tr height="5px">
					<td colspan="4">&nbsp; </td>
				</tr>
					
					<tr> 
						<td colspan="4" font-family = Arial font-size = 9pt>&nbsp; <b>
						Permite a inclusão de Usuarios no Sistema.</b>
						</td>
					</tr>
						
						<tr height="20px">
							<td colspan="4">&nbsp; </td>
						</tr>
		</td>
	</tr>
	</table>
	<table class= "usuario">
				<tr> 
					<td>&nbsp; </td>
					<td width="10px"> Nome: </td>
					<td><input type="text" name="txtnome" size="50" maxlength="50" value=""> </td>
					<td> &nbsp; </td>
				</tr>
								
				<tr>
					<td>&nbsp;</td>
					<td> Usuario: </td>
					<td><input type="text" name="txtusuario" size="8" maxlength="8" value=""> </td>
					<td> &nbsp; </td>
											
				</tr>
										
				<tr> 
					<td>&nbsp;</td>
					<td> Senha: </td>
					<td><input type="password" name="txtsenha" size="8" maxlength="8" value=""> </td>
					<td> &nbsp; </td>
				</tr>
			
			<tr>
				<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
			
			
		<tr>		
			<td>&nbsp;</td>
			<td  colspan=2> Perfil Usuario: </td>
		</tr>
				
			<tr>
				<td colspan=2> </td>
				<td> <input type="radio" name="txtperfil" value="1"> Administrador </td>
			</tr>
		
			<tr>
				<td colspan=2> </td>
				<td> <input type="radio" name="txtperfil" value="2"> Controle Estoque</td>
			</tr>
			
			<tr>
					<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
		
		
		<tr>
				<td>&nbsp </td>
				<td> Departamento: </td>
				<td>
					<?php echo combodepto(); ?>
				</td>
		</tr>
		
			<tr>
					<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
		
		<tr>		
			<td>&nbsp;</td>
			<td> Cursos de Lingua:  </td>		
			<td>
					<select name="nome" size=4>
						<option value='1'> Inglês 
						<option value='2'> Espanhol
						<option value='3'> Francês
						<option value='4'> Outros
					</select>
			</td>
		</tr>
		
		<tr>
					<td  colspan="10"> 
					<HR width="100%" align="center" size="1" color="blue">
			</tr>
		
		
		<tr>		
			<td>&nbsp;</td>
			<td  colspan=4> Hobbys que o funcionario prática: </td>
		</tr>
		
		<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="caminhada" />Caminhada </td>
			</tr>
			
			<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="corrida" value="2" /> Corrida</td>
			</tr>
			
			<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="Dança" value="3" />Dança </td>
			</tr>
			
			<tr>
			<td colspan=2>&nbsp;</td>
			<td><input type="checkbox" name="futebol" value="4" />Futebol </td>
			</tr>
			
			<tr>
					<td colspan="2"> &nbsp; </td>
					<td align="left"> <input type="button" name="Incluir" value="Incluir" onclick="JavaScript:ValidaUsuario();"> </td>
					<td> &nbsp; </td>
		</tr>
	</table>
</table>
	
</form>
</body>

</html>