<?php
session_start();
include("fileset.php");

$loginusu = $_POST['txtusuario'];
include("php/conexao.php");

$SQL ='';
$SQL .= ' DELETE from usuario ';
$SQL .= ' WHERE login = '.chr(39).$loginusu.chr(39).' ';
$SQL .= ' ';

$wresultado = mysqli_query($conexao, $SQL);
if (!$wresultado)
{
	$mensagem_erro = 'Erro de sintaxe na query: '.mysqli_error();
	$destino = 'http://localhost/Projeto2/php/erro.php?msg='.$mensagem_erro;
	header("Location: $destino");
	exit;
}
else
{
	mysqli_close($conexao);
	$destino = 'http://localhost/Projeto2/usuario-lista.php';
	header("Location: $destino");
	exit;
}
?>