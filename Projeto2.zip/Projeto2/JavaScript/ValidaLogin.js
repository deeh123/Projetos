function ValidaLogin()
{
	
	if(document.frmlogin.txtusuario.value=="")
	{
		document.frmlogin.txtusuario.style.background = 'Yellow';
		alert("Favor preencher o Nome do Usuario.");
		document.frmlogin.txtusuario.focus();
		return false;
	}
	else
		document.frmlogin.txtusuario.style.background = 'White';
		
		if(document.frmlogin.txtsenha.value=="")
	{
		document.frmlogin.txtsenha.style.background = 'Yellow';
		alert("`Por favor preencher sua senha.");
		document.frmlogin.txtsenha.focus();
		return false;
	}
	else
		document.frmlogin.txtsenha.style.background = 'White';
		
	document.forms[0].action="http://localhost/projeto2/pagina_inicial.php";
	document.forms[0].submit();
}