document.write("               <div id='menu'>");
document.write("               		<ul>");
document.write("	         			<li><a href='http://localhost/projeto2/pagina_inicial.html'>Home</a></li>");
document.write("	         			<li><a href='http://localhost/projeto2/produto/prod-incluir.html'>Produtos</a></li>");
document.write("	         			<li><a href=''>Estoque</a></li>");
document.write("	         			<li><a href=''>Relat&oacuterio</a></li>");
document.write("	         			<li><a href='http://localhost/projeto2/usuario-lista.php'>Admin</a></li>");
document.write("               		</ul>");
document.write("               	</div>");
