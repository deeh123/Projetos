document.write("    <tr bgcolor=#4682B4>");
document.write("      <td width='34%' colspan='2'></td>");
document.write("      <td width='49%'> <font size='6' align='center' color='white'>Controle de Estoque</font></td>");
document.write("      <td width='17%' align='right'><img src='http://localhost/projeto2/imagem/faex.jpg'></td>");
document.write("    </tr>");
document.write("    <tr height='5px'>");
document.write("      <td colspan='4' align='right' valign='bottom'>");
document.write("        <span' style='background-color: #EBEBEB; font-size:9pt;'>");
document.write(DataCorrente() + "<br>");
document.write("        </span>");
document.write("        <a href='http://localhost/projeto2/pagina_inicial.html'><b>In&iacute;cio</b></a>&nbsp;&nbsp;<span style='color:lightblue; font-weight:bolder;'>|</span>&nbsp;&nbsp;");
document.write("        <b>Usu&aacute;rio:&nbsp;</b>Master&nbsp;&nbsp;<span style='color:lightblue; font-weight:bolder;'>|</span>&nbsp;&nbsp;");
document.write("        <a href='http://localhost/projeto2/index.html'><b>Trocar de Usu&aacute;rio&nbsp;</b></a>&nbsp;&nbsp;<span style='color:lightblue; font-weight:bolder;'>|</span>&nbsp;&nbsp;");
document.write("        <a href='http://localhost/projeto2/index.html'><b>Sair</b></a>&nbsp;&nbsp;<span style='color:lightblue; font-weight:bolder;'>|</span>&nbsp;&nbsp;");
document.write("      </td>");
document.write("    </tr>");



function DataCorrente()
{
data_corrente = new Date();        //criando o objeto data
dia = data_corrente.getDate();     //obtendo o dia, retorno de 1 a 31
wdia_semana = data_corrente.getDay(); // retorna o n�mero inteiro do dia da semana
dia_semana = "";  //definindo vari�vel
mes = "";         //definindo vari�vel


switch (wdia_semana)   //convertendo o n�mero do dia da semana para texto
{
   case 0 : dia_semana = "Domingo"; break;
   case 1 : dia_semana = "Segunda"; break;
   case 2 : dia_semana = "Ter\u00E7a"; break;
   case 3 : dia_semana = "Quarta"; break;
   case 4 : dia_semana = "Quinta"; break;
   case 5 : dia_semana = "Sexta"; break;
   case 6 : dia_semana = "S\u00E0bado"; break;
   default: dia_semana = "erro";
}

//if (wdia_semana == 2) dia_semana = "Terca";

wmes = data_corrente.getMonth();  //obtendo o m�s

switch (wmes) //convertendo o n�mero do m�s para m�s em texto
{
   case 0 : mes = "Janeiro"; break;
   case 1 : mes = "Fevereiro"; break;
   case 2 : mes = "Mar\u00E7o"; break;
   case 3 : mes = "Abril"; break;
   case 4 : mes = "Maior"; break;
   case 5 : mes = "Junho"; break;
   case 6 : mes = "Julho"; break;
   case 7 : mes = "Agosto"; break;
   case 8 : mes = "Setembro"; break;
   case 9 : mes = "Outubro"; break;
   case 10 : mes = "Novembro"; break;
   case 11 : mes = "Dezembro"; break;
   default: mes = "erro";
}

ano = data_corrente.getFullYear(); //obtendo o ano
  // retornando para tela o dia da semana e a data

//alert(dia);
//document.forms[0].labeldata.value = dia_semana + ", " + dia + " de " + mes + " de " + ano;
data_corrente_display = dia_semana + ", " + dia + " de " + mes + " de " + ano;
return(data_corrente_display);
}
