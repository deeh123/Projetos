<?php
//Faz a conexão com SGBD, como não tem senha, apos root não vai nada
//Se tivesse senha seria ... 'root','senha')

//A função mysql_connect pega o host do banco de dados, nome do usuário e senha como parâmetros.
//Se a conexão for bem sucedida, um link para um banco de dados é retornado.

$conexao = mysqli_connect('localhost','root','','controleestoque');

//FALSE retorna quando uma conexão não pode ser feita. Verifique o valor retornado da função para
//certificar-se de que há uma conexão. Se houver um problema, como uma senha incorreta, imprima um
//alerta educado e a razão do erro utilizando mysql_error.

//No lugar de simplesmente ecoar uma mensagem de erro, die() exibe o erro e para o programa. Não
//conseguir ter acesso ao banco de dados torna a maioria das páginas guiadas por banco de dados 
//praticamente inúteis e impede que o usuário veja diversos erros.

//Note que não especificamos o nome do banco de dados ainda.

if (!$conexao) {
      die('Falha na conexão com o MySQL: ' . mysqli_error());
}
?>