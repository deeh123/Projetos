<?php

function validaUsuario($logindigitado, $senhadigitada)

{
			include("php/conexao.php");


		$SQL  = '';
		$SQL .= 'SELECT nome ';
		$SQL .= ' FROM usuario ';
		$SQL .= ' WHERE login = '.chr(39).$logindigitado.chr(39);
		$SQL .= ' AND senha = '.chr(39).$senhadigitada.chr(39).';';
							
		$resultado = mysqli_query($conexao,$SQL);

		if (!$resultado)
		{
			$mensagem_erro  = 'Erro de sintaxe na query:'.mysqli_error()."<br>";
			$mensagem_erro .= 'SQL executado:' . $SQL;
			$destino = 'http://localhost/Projeto2/php/erro.php?msg='.$mensagem_erro;
			header("Location:$destino");
			exit;
		}

		if (mysqli_num_rows($resultado) == 0)
		{
			$mensagem_erro .= 'Usuario ou senha não localizados';
			$mensagem_erro .= 'SQL executado:' . $SQL;
			$destino = 'http://localhost/Projeto2/php/erro.php?msg='.$mensagem_erro;
			header("Location:$destino");
			exit;
		}


	$resultado_row = mysqli_fetch_row($resultado);
	return $resultado_row[0];

	// fecha a conexao
	mysqli_close($conexao);

}
?>






