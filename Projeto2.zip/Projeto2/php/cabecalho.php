<?php

echo '      <tr bgcolor= #4682B4 >';
echo '      <td width="34%" colspan="2"></td>';
echo '      <td width="49%"> <font size="6" align="center" color="white">Controle de Estoque</font></td>';
echo '      <td width="17%" align="right"><img src="http://localhost/projeto2/imagem/faex.jpg"></td>';
echo '      </tr>';
echo '      <tr height="5px">';
echo '      <td colspan="4" align="right" valign="bottom">';
echo '      <span " style=" background-color: #EBEBEB; font-size:9pt;">';
echo 		$_SESSION["datacorrente"];
echo '      </span>';
echo ' 		<b>Usu&aacute;rio:&nbsp;</b>'.$_SESSION["nomeusuario"].'&nbsp;<span style="color:lightblue; font-weight:bolder;">|</span>&nbsp;&nbsp;';
echo '      <a href="http://localhost/projeto2/index.php"><b>Trocar de Usu&aacute;rio&nbsp;</b></a>&nbsp;&nbsp;<span style="color:lightblue; font-weight:bolder;">|</span>&nbsp;&nbsp;';
echo '      <a href="http://localhost/projeto2/index.php"><b>Sair</b></a>&nbsp;&nbsp;<span style="color:lightblue; font-weight:bolder;">|</span>&nbsp;&nbsp;';
echo '      </td>';
echo '    </tr>';

?>