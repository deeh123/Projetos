<?php 
$mensagem = $_GET["msg"];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="http://localhost/Projeto2/css/estilo.css" type="text/css" />
	<script type="text/javascript" src="http://localhost/Projeto2/script/ValidaLogin.js" charset="utf-8"></script>	
</head>
<body>
	<form name="frmlogin" method="post">
	<table class="pagina">
			
			<tr class="cabecalho" >
				<td width="34%" colspan="2"></td>
				<td width="49%">
					<font size="6" align="center" color="white">
						Controle de Estoque
					</font>
				</td>
				<td width="17%" align="right"><img src="http://localhost/Projeto2/imagem/faex.jpg"></td>
			
			</tr>
		
			<tr height="5px">
					<td colspan="4">&nbsp;</td>
			</tr>		
		    
			<tr height="5px"> <!-- Divisao do cabeçalho com o corpo da pagina -->
					<!-- NOSHADE indicates that the rule should be presented 
					as flat instead of three dimensional -->
					<td colspan="4"><hr noshaded size="1" color="#4682B4"></td>
			</tr>
	   <tr height="5px"> <!-- Divisão do cabeçalho com o corpo da pagina -->
      <td colspan="3"><hr></td>
    </tr>
    
    <tr> <!-- Corpo da pagina -->
      <td colspan="3">
        <table align="center" width="80%" cellpadding="0" cellspacing="0" border="0" style="font-size:10pt; font-family:Arial Black; color:Red;">
           <tr>
              <td align="center"><br><?php echo $mensagem; ?></td>
           </tr>
           <tr><td><hr></td></tr>
           <tr>
              <td align="center">
                 <input type="button" name="botaovoltar" value="Voltar" onclick="JavaScript:history.back();">
              </td>
           </tr>
         </table>	
      </td>
    </tr>

	</table>
</form>
</body>

</html>
