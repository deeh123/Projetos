<?php
/*
 *      funcoes_genericas.php
 *      
 *      Copyright 2015 Andrea Leme
 *      
 *      Este arquivo contém funções genéricas usadas ao longo do sistema.
 *      Alterações neste arquivo são refletidas em todo o sistema. Caso
 *      seja necessário alterar algum função por conta de uma situação
 *      específica, recomenda-se replicar a função dando-lhe outro nome
 *      e utilizar esta nova função para atender ao requisito necessário.
  *      
 */

/* *********************************************************************
 *  Monta a string de data corrente para exibição no cabeçalho
 * *********************************************************************
*/
function exibedatacorrente()
{

	$dia = date('d');
	$mes = date('m');
	$ano = date('Y');

    $dayofweek = date('N', strtotime(date('ymd')));
    $monthofyear = date('n', strtotime(date('ymd')));
    
    switch ($dayofweek)
    {
          case 1 : $diasemana = 'Segunda-feira';  break;
          case 2 : $diasemana = 'Terça-feira';  break;
          case 3 : $diasemana = 'Quarta-feira';  break;
          case 4 : $diasemana = 'Quinta-feira';  break;
          case 5 : $diasemana = 'Sexta-feira';  break;
          case 6 : $diasemana = 'Sábado';  break;
          case 7 : $diasemana = 'Domingo';  break;
     }
     
     switch ($monthofyear)
     {
          case 1 : $mescorrente = 'Janeiro';  break;
          case 2 : $mescorrente = 'Fevereiro';  break;
          case 3 : $mescorrente = 'Março';  break;
          case 4 : $mescorrente = 'Abril';  break;
          case 5 : $mescorrente = 'Maio';  break;
          case 6 : $mescorrente = 'Junho';  break;
          case 7 : $mescorrente = 'Julho';  break;
          case 8 : $mescorrente = 'Agosto';  break;
          case 9 : $mescorrente = 'Setembro';  break;
          case 10 : $mescorrente = 'Outubro';  break;
          case 11 : $mescorrente = 'Novembro';  break;
          case 12 : $mescorrente = 'Dezembro';  break;
	 }
	
	$data_display = $diasemana.', '.$dia.' de '.$mescorrente.' de '.$ano;
	
	return $data_display;

}

// *************************************************************************************
//  Troca acentuacao
// *************************************************************************************
function Acentuacao($eString)
{
      $sString = $eString;
      $sString = str_replace("Á","&Aacute;",$sString);
      $sString = str_replace("á","&aacute;",$sString);
      $sString = str_replace("À","&Agrave;",$sString);
      $sString = str_replace("à","&agrave;",$sString);
      $sString = str_replace("Â","&Acirc;",$sString);
      $sString = str_replace("â","&acirc;",$sString);
      $sString = str_replace("Ä","&Auml;",$sString);
      $sString = str_replace("ä","&auml;",$sString);
      $sString = str_replace("Ã","&Atilde;",$sString);
      $sString = str_replace("ã","&atilde;",$sString);
      $sString = str_replace("Å","&Aring;",$sString);
      $sString = str_replace("Ç","&Ccedil;",$sString);
      $sString = str_replace("ç","&ccedil;",$sString);
      $sString = str_replace("ð","&eth;",$sString);
      $sString = str_replace("É","&Eacute;",$sString);
      $sString = str_replace("é","&eacute;",$sString);
      $sString = str_replace("È","&Egrave;",$sString);
      $sString = str_replace("è","&egrave;",$sString);
      $sString = str_replace("Ê","&Ecirc;",$sString);
      $sString = str_replace("ê","&ecirc;",$sString);
      $sString = str_replace("Ë","&Euml;",$sString);
      $sString = str_replace("ë","&euml;",$sString);
      $sString = str_replace("Í","&Iacute;",$sString);
      $sString = str_replace("í","&iacute;",$sString);
      $sString = str_replace("Ì","&Igrave;",$sString);
      $sString = str_replace("ì","&igrave;",$sString);
      $sString = str_replace("Î","&Icirc;",$sString);
      $sString = str_replace("î","&icirc;",$sString);
      $sString = str_replace("Ï","&Iuml;",$sString);
      $sString = str_replace("ï","&iuml;",$sString);
      $sString = str_replace("Ó","&Oacute;",$sString);
      $sString = str_replace("ó","&oacute;",$sString);
      $sString = str_replace("Ò","&Ograve;",$sString);
      $sString = str_replace("ò","&ograve;",$sString);
      $sString = str_replace("Ô","&Ocirc;",$sString);
      $sString = str_replace("ô","&ocirc;",$sString);
      $sString = str_replace("ö","&ouml;",$sString);
      $sString = str_replace("Õ","&Otilde;",$sString);
      $sString = str_replace("õ","&otilde;",$sString);
      $sString = str_replace("Ú","&Uacute;",$sString);
      $sString = str_replace("ú","&uacute;",$sString);
      $sString = str_replace("Ù","&Ugrave;",$sString);
      $sString = str_replace("ù","&ugrave;",$sString);
      $sString = str_replace("Û","&Ucirc;",$sString);
      $sString = str_replace("û","&ucirc;",$sString);
      $sString = str_replace("Ü","&Uuml;",$sString);
      $sString = str_replace("ü","&uuml;",$sString);
      $sString = str_replace("ý","&yacute;",$sString);
      $sString = str_replace("ÿ","&yuml;",$sString);

      return $sString;
}
?>
