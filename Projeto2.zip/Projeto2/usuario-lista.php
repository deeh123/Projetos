<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<?php
session_start();
include("fileset.php");
$tag = obtemlistausuario();
?>

<html>

	<head>

	<meta http-equiv="Content-type" content="text/html; charset=UTF-8"> 
		<link rel="stylesheet" href="http://localhost/projeto2/css/menu.css" type="text/css" />
		<link rel="stylesheet" href="http://localhost/projeto2/css/estilo.css" type="text/css" />
		
		<title>
		  Incluir Usuário
		</title>
	
	</head>

<body>

	<form name="frmusuario" method="post">

<table style="width:100%; border-collapse: collapse; border-spacing: 0;">

	<?php include("php/cabecalho.php");?>
	

	<tr height="5px">
		<td colspan="4"> <hr noshaded size="1" color="lightblue"> </td>
	</tr>
	
	<tr>
		<td colspan="3"> 
		
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
			<tr width="12%" valign="top">
				<script src="http://localhost/projeto2/script/menu.js"> </script>
			</tr>
				
				<tr height="5px">
					<td colspan="4">&nbsp; </td>
				</tr>
					
					<tr> 
						<td colspan="4" font-family = Arial font-size = 9pt>&nbsp; <b>
							Consulta de Usuários Cadastrados</b>
						</td>
					</tr>
						
						<tr height="20px">
							<td colspan="4">&nbsp; </td>
						</tr>
		</table>
		
		<table class = "usuario">
			<tr>
				<td colspan="4">
					<?php echo $tag;?>
				</td>
			</tr>
		</table>
		
		
</table>
	
</form>
</body>

</html>